package com.example.ecommerceclone.Prevalent;

import com.example.ecommerceclone.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
